extends CharacterBody2D
class_name PartyFollower
## 파티 팔로워: 리더의 이동 경로를 Snake처럼 따라감
## AnimatedSprite2D로 4방향 걷기 애니메이션 지원
## 스프라이트 위에 HP바 + ATB바 표시

@export var follow_index: int = 1
@export var follow_speed: float = 80.0  # 리더와 동일한 속도

var leader: PartyLeader = null
var target_position: Vector2 = Vector2.ZERO
var facing_right: bool = false
var current_direction: String = "down"  # "down", "up", "left", "right"
var hero_id: String = ""
var hero_data: Dictionary = {}

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var hp_bar: ProgressBar = $StatusBars/HPBar
@onready var atb_bar: ProgressBar = $StatusBars/ATBBar

# 공격 이펙트용
var attack_icon: Label = null
const ATTACK_ICONS: Dictionary = {
	"warrior": "⚔️",
	"knight": "🗡️",
	"thief": "🔪",
	"archer": "🏹",
	"mage": "✨",
	"cleric": "✝️"
}


func _ready() -> void:
	add_to_group("party_follower")
	add_to_group("party")
	_create_attack_icon()
	
	# BattleManager ATB 시그널 연결
	if BattleManager:
		BattleManager.hero_atb_changed.connect(_on_hero_atb_changed)
		BattleManager.hero_attacked.connect(_on_hero_attacked)


func _physics_process(_delta: float) -> void:
	if not is_instance_valid(leader):
		return
	
	target_position = leader.get_position_at_offset(follow_index)
	var distance := global_position.distance_to(target_position)
	
	# 더 가까이 붙어있도록 threshold 줄임
	var start_threshold := 4.0
	var stop_threshold := 2.0
	
	var was_moving := velocity.length() > 1.0
	
	if distance > start_threshold or (was_moving and distance > stop_threshold):
		var direction := (target_position - global_position).normalized()
		velocity = direction * follow_speed
		_update_direction(direction)
		_play_walk_animation()
	else:
		velocity = Vector2.ZERO
		# Idle 시에는 리더의 방향을 따라감
		if leader:
			current_direction = leader.get_current_direction()
		_play_idle_animation()
	
	move_and_slide()
	
	# HP 바 업데이트
	_update_hp_bar()


func _create_attack_icon() -> void:
	## 공격 이펙트용 아이콘 생성
	attack_icon = Label.new()
	attack_icon.text = "⚔️"
	attack_icon.add_theme_font_size_override("font_size", 16)
	attack_icon.position = Vector2(-8, -32)
	attack_icon.z_index = 20
	attack_icon.visible = false
	add_child(attack_icon)


func _on_hero_attacked(attacked_hero_id: String) -> void:
	## 이 영웅이 공격했을 때 이펙트 재생
	if attacked_hero_id == hero_id:
		_play_attack_effect()


func _play_attack_effect() -> void:
	## 검 휘두르는 이펙트
	if not attack_icon:
		return
	
	# 직업에 맞는 아이콘
	var class_id: String = hero_data.get("class_id", "warrior")
	attack_icon.text = ATTACK_ICONS.get(class_id, "⚔️")
	
	# 방향에 따라 시작 위치/각도 설정
	var start_x: float = -12.0 if not facing_right else 12.0
	var end_x: float = 12.0 if not facing_right else -12.0
	var start_rot: float = -45.0 if not facing_right else 45.0
	var end_rot: float = 45.0 if not facing_right else -45.0
	
	attack_icon.position = Vector2(start_x, -28)
	attack_icon.rotation_degrees = start_rot
	attack_icon.visible = true
	attack_icon.modulate = Color.WHITE
	
	# 휘두르는 애니메이션
	var tween = create_tween()
	tween.set_parallel(true)
	
	# 호 그리며 이동 (위로 갔다가 내려옴)
	tween.tween_property(attack_icon, "position:x", end_x, 0.15).set_ease(Tween.EASE_OUT)
	tween.tween_property(attack_icon, "position:y", -35, 0.07).set_ease(Tween.EASE_OUT)
	tween.tween_property(attack_icon, "rotation_degrees", end_rot, 0.15).set_ease(Tween.EASE_OUT)
	
	# 0.07초 후 아래로
	tween.chain().tween_property(attack_icon, "position:y", -28, 0.08).set_ease(Tween.EASE_IN)
	
	# 페이드 아웃
	tween.chain().tween_property(attack_icon, "modulate:a", 0.0, 0.1)
	tween.chain().tween_callback(func(): attack_icon.visible = false)


func _update_hp_bar() -> void:
	if not hp_bar or hero_id.is_empty():
		return
	
	var hero: Hero = PartyManager.get_hero_by_id(hero_id)
	if hero:
		var percent: float = float(hero.current_hp) / float(hero.get_max_hp()) * 100.0
		hp_bar.value = percent
		
		# HP 낮으면 색상 변경
		var fill_style: StyleBoxFlat = hp_bar.get_theme_stylebox("fill").duplicate()
		if percent <= 25:
			fill_style.bg_color = Color(0.9, 0.2, 0.2)
		elif percent <= 50:
			fill_style.bg_color = Color(0.9, 0.7, 0.2)
		else:
			fill_style.bg_color = Color(0.2, 0.8, 0.2)
		hp_bar.add_theme_stylebox_override("fill", fill_style)


func _on_hero_atb_changed(changed_hero_id: String, value: float) -> void:
	if changed_hero_id == hero_id and atb_bar:
		atb_bar.value = value * 100.0
		
		# ATB가 거의 찼을 때 색상 변경
		var fill_style: StyleBoxFlat = atb_bar.get_theme_stylebox("fill").duplicate()
		if value >= 0.9:
			fill_style.bg_color = Color(1.0, 1.0, 0.5)
		else:
			fill_style.bg_color = Color(1.0, 0.8, 0.2)
		atb_bar.add_theme_stylebox_override("fill", fill_style)


func _update_direction(move_dir: Vector2) -> void:
	## 이동 방향에 따라 현재 방향 및 facing_right 업데이트
	# 8방향 입력을 4방향으로 변환 (수평 우선)
	if abs(move_dir.x) > abs(move_dir.y):
		# 좌우 이동 우선
		if move_dir.x > 0:
			current_direction = "right"
			facing_right = true
		else:
			current_direction = "left"
			facing_right = false
	else:
		# 상하 이동
		if move_dir.y > 0:
			current_direction = "down"
		else:
			current_direction = "up"
		# 상하 이동 시 좌우 보조입력으로 facing 결정
		if move_dir.x > 0.1:
			facing_right = true
		elif move_dir.x < -0.1:
			facing_right = false


func _play_walk_animation() -> void:
	## 현재 방향에 맞는 걷기 애니메이션 재생
	if not animated_sprite:
		return
	
	var anim_name: String = "walk_" + current_direction
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation(anim_name):
		if animated_sprite.animation != anim_name or not animated_sprite.is_playing():
			animated_sprite.play(anim_name)


func _play_idle_animation() -> void:
	## 현재 방향에 맞는 대기 애니메이션 (첫 프레임에서 정지)
	if not animated_sprite:
		return
	
	var anim_name: String = "walk_" + current_direction
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation(anim_name):
		# 이미 같은 애니메이션이고 멈춰있으면 아무것도 안 함
		if animated_sprite.animation == anim_name and not animated_sprite.is_playing():
			return
		animated_sprite.stop()
		animated_sprite.animation = anim_name
		animated_sprite.frame = 0


func setup(p_leader: PartyLeader, p_index: int, hero: RefCounted = null) -> void:
	leader = p_leader
	follow_index = p_index
	global_position = leader.get_position_at_offset(follow_index)
	facing_right = leader.get_facing_right()
	current_direction = leader.get_current_direction()
	
	if hero:
		hero_id = hero.id
		hero_data = {
			"id": hero.id,
			"name": hero.hero_name,
			"class_id": hero.class_id
		}
		
		# SpriteManager에서 스프라이트시트 로드 및 애니메이션 설정
		if SpriteManager and animated_sprite:
			var sprite_frames: SpriteFrames = SpriteManager.get_hero_sprite_frames(hero_id)
			if sprite_frames:
				animated_sprite.sprite_frames = sprite_frames
				animated_sprite.animation = "walk_" + current_direction
				animated_sprite.frame = 0
	
	# 초기 HP 업데이트
	_update_hp_bar()
